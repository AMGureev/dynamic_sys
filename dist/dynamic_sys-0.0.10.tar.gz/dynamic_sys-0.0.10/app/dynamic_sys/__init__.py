from .src.BallMagSystem import (
    BallMagSystem
)

from .src.DataGen import (
    DataGen,
)
